//
//  MenuBocinaViewController.swift
//  pumna
//
//  Created by Usuario invitado on 12/3/18.
//  Copyright © 2018 Guest User. All rights reserved.
//

import UIKit

class MenuBocinaViewController: UIViewController {
    @IBAction func CaracteristicaBocinaView(segue:UIStoryboardSegue){
    }
    @IBAction func AplicacionesBocinaView(segue:UIStoryboardSegue){
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
