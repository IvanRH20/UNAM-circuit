//
//  MenuTransistoresViewController.swift
//  pumna
//
//  Created by Rodrigo Ocaña on 30/11/18.
//  Copyright © 2018 Guest User. All rights reserved.
//

import UIKit

class MenuTransistoresViewController: UIViewController {
    @IBAction func RegresodeTiposdeTransistoresView(segue:UIStoryboardSegue){
    }
    @IBAction func RegresodeInfoTransist(segue:UIStoryboardSegue){
    }
    @IBAction func AplicacionesTransistoresView(segue:UIStoryboardSegue){
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
