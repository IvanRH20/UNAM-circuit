//
//  MenuTransformadorViewController.swift
//  pumna
//
//  Created by Macbook on 12/4/18.
//  Copyright © 2018 Guest User. All rights reserved.
//

import UIKit

class MenuTransformadorViewController: UIViewController {
    @IBAction func InfoTransfView (segue:UIStoryboardSegue){
    }
    @IBAction func AplicaTransfView (segue:UIStoryboardSegue){
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
