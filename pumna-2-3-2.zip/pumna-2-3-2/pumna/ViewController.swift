//
//  ViewController.swift
//  pumna
//
//  Created by Guest User on 11/12/18.
//  Copyright © 2018 Guest User. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var Resistencia: UIButton!
    @IBAction func ResistenciaView(segue:UIStoryboardSegue){
    }
    @IBOutlet weak var Capacitor: UIButton!
    @IBAction func CapacitorView(segue:UIStoryboardSegue){
    }
    @IBOutlet weak var transitor: UIButton!
    @IBAction func TransistorView(segue:UIStoryboardSegue){
    }
    @IBOutlet weak var CircuitosIntegrados: UIButton!
    @IBAction func CircuitosIntegradosView(segue:UIStoryboardSegue){
    }
    @IBOutlet weak var Potenciómetro: UIButton!
    @IBAction func PotenciometroView(segue:UIStoryboardSegue){
    }
    @IBOutlet weak var Diodo: UIButton!
    @IBAction func DiodoView(segue: UIStoryboardSegue){
    }
    @IBOutlet weak var Transformadores: UIButton!
    @IBAction func TransformadoresView(segue: UIStoryboardSegue){
    }
    @IBOutlet weak var Voltimetro: UIButton!
    @IBAction func VoltimetroView(segue:UIStoryboardSegue){
    }
    @IBOutlet weak var Bocina: UIButton!
    @IBAction func BocinaView(segue:UIStoryboardSegue){
    }
    @IBAction func fromCodigodecoloresView(segue:UIStoryboardSegue){
    }
    @IBAction func CalculadoraCapacitoresView(segue: UIStoryboardSegue){
    }
    @IBAction func InformacionResistView (segue: UIStoryboardSegue){
    }
    @IBAction func FormulasResistView (segue:UIStoryboardSegue){
    }
    @IBAction func InformacionTransistView (segue: UIStoryboardSegue){
    }
    @IBAction func AplicaTransistView (segue:UIStoryboardSegue){
    }
    @IBAction func TiposTranstView (segue: UIStoryboardSegue){
    }
    @IBAction func NPNView (segue: UIStoryboardSegue){
    }
    @IBAction func PNPView (segue:UIStoryboardSegue){
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

